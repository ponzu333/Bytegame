import pygame
import pymunk
import pymunk.pygame_util
import random
import math

# 初期設定
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()
space = pymunk.Space()
space.gravity = (0, 900)  # 重力を設定 (下方向)

# フォントの設定
font = pygame.font.SysFont("Arial", 24)
game_over_font = pygame.font.SysFont("Arial", 48)

# Pymunkの描画ヘルパー
draw_options = pymunk.pygame_util.DrawOptions(screen)

# ボールのサイズとスコアのリスト
ball_sizes = [15, 16, 20, 32, 38, 40, 55, 85, 80, 100, 180]  # サイズを調整
ball_scores = [2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048]  # スコアを調整

# 背景画像の読み込みとスケーリング
background_image = pygame.image.load("images/background.png")
background_image = pygame.transform.scale(background_image, (800, 600))

# 画像の読み込み
ball_images = [
    pygame.image.load("images/image1.png"),
    pygame.image.load("images/image2.png"),
    pygame.image.load("images/image3.png"),
    pygame.image.load("images/image4.png"),
    pygame.image.load("images/image5.png"),
    pygame.image.load("images/image6.png"),
    pygame.image.load("images/image7.png"),
    pygame.image.load("images/image8.png"),
    pygame.image.load("images/image9.png"),
    pygame.image.load("images/image10.png"),
    pygame.image.load("images/image11.png")
]

# 画像のサイズ変更（アスペクト比を保持してスケーリング）
for i in range(len(ball_sizes)):
    original_width, original_height = ball_images[i].get_size()
    scale_factor = (ball_sizes[i] * 2) / max(original_width, original_height)
    new_size = (int(original_width * scale_factor), int(original_height * scale_factor))
    ball_images[i] = pygame.transform.smoothscale(ball_images[i], new_size)

# 効果音の読み込み
spawn_sound = pygame.mixer.Sound("sounds/spawn.mp3")
combine_sounds = [
    pygame.mixer.Sound("sounds/combine1.mp3"),
    pygame.mixer.Sound("sounds/combine2.mp3"),
    pygame.mixer.Sound("sounds/combine3.mp3"),
    pygame.mixer.Sound("sounds/combine4.mp3"),
    pygame.mixer.Sound("sounds/combine5.mp3"),
    pygame.mixer.Sound("sounds/combine6.mp3"),
    pygame.mixer.Sound("sounds/combine7.mp3"),
    pygame.mixer.Sound("sounds/combine8.mp3"),
    pygame.mixer.Sound("sounds/combine9.mp3"),
    pygame.mixer.Sound("sounds/combine10.mp3"),
    pygame.mixer.Sound("sounds/combine11.mp3")
]

# スコアの初期化
score = 0

class Ball:
    def __init__(self, body, shape, size_index):
        self.body = body
        self.shape = shape
        self.size_index = size_index

# 床と壁を作成
def create_walls(space):
    wall_thickness = 15  # 壁の幅をさらに太くする
    floor = pymunk.Segment(space.static_body, (200, 550), (600, 550), wall_thickness)
    left_wall = pymunk.Segment(space.static_body, (200, 100), (200, 550), wall_thickness)
    right_wall = pymunk.Segment(space.static_body, (600, 100), (600, 550), wall_thickness)
    floor.friction = 0.5
    left_wall.friction = 0.5
    right_wall.friction = 0.5
    space.add(floor, left_wall, right_wall)

# 壁を描画する関数
def draw_walls(screen):
    color = (128, 128, 128)  # 壁の色をグレーに設定
    wall_thickness = 15  # 壁の幅をさらに太くする
    pygame.draw.rect(screen, color, (200, 100, wall_thickness, 450))  # 左の壁
    pygame.draw.rect(screen, color, (600 - wall_thickness, 100, wall_thickness, 450))  # 右の壁（右端から引いて位置を調整）
    pygame.draw.rect(screen, color, (200, 550 - wall_thickness, 400, wall_thickness))  # 床（下端から引いて位置を調整）

# ボールを作成
def create_ball(space, size_index, pos):
    radius = ball_sizes[size_index] - 5  # 半径を調整して透明な余白を削除
    body = pymunk.Body(1, pymunk.moment_for_circle(1, 0, radius))
    body.position = pos
    shape = pymunk.Circle(body, radius)
    shape.elasticity = 0.8
    shape.friction = 0.5  # ボールの摩擦を設定
    shape.collision_type = 1  # 衝突タイプを設定
    ball = Ball(body, shape, size_index)
    shape.ball = ball  # ボールオブジェクトを形状に関連付け
    space.add(body, shape)
    spawn_sound.play()  # ボール出現時の効果音を再生
    return ball

def combine_balls(arbiter, space, data):
    global score
    shapes = arbiter.shapes
    ball1 = shapes[0].ball
    ball2 = shapes[1].ball

    if ball1.size_index == ball2.size_index:
        if ball1.size_index < len(ball_sizes) - 1:
            new_size_index = ball1.size_index + 1
            new_ball = create_ball(space, new_size_index, ball1.body.position)
            if ball1 not in remove_balls:
                remove_balls.append(ball1)
            if ball2 not in remove_balls:
                remove_balls.append(ball2)
            balls.append(new_ball)
            score += ball_scores[ball1.size_index]  # スコアを更新
            combine_sounds[ball1.size_index].play()  # ボール合体時の個別の効果音を再生
        else:
            # 一番大きいサイズ同士が衝突した場合は両方とも消滅する
            if ball1 not in remove_balls:
                remove_balls.append(ball1)
            if ball2 not in remove_balls:
                remove_balls.append(ball2)
            score += ball_scores[ball1.size_index]  # スコアを更新
            combine_sounds[ball1.size_index].play()  # ボール合体時の個別の効果音を再生

    return False

# 衝突ハンドラーの設定
handler = space.add_collision_handler(1, 1)
handler.post_solve = combine_balls

create_walls(space)

def draw_ball(screen, ball):
    img = ball_images[ball.size_index]
    angle = -math.degrees(ball.body.angle)  # ラジアンを度に変換し、負の値にする
    rotated_img = pygame.transform.rotate(img, angle)
    rect = rotated_img.get_rect(center=(int(ball.body.position.x), int(ball.body.position.y)))
    screen.blit(rotated_img, rect.topleft)

def is_position_free(pos, balls):
    for ball in balls:
        distance = ((pos[0] - ball.body.position.x) ** 2 + (pos[1] - ball.body.position.y) ** 2) ** 0.5
        if distance < ball.shape.radius * 2:
            return False
    return True

def draw_next_ball(screen, index):
    img = ball_images[index]
    img_rect = img.get_rect()
    text = font.render("NEXT:", True, (0, 0, 0))
    # 中央あたりに表示するためにy座標を調整
    y_pos = screen.get_height() // 2 - img_rect.height
    screen.blit(text, (screen.get_width() - img_rect.width - 50, y_pos - 30))  # 「NEXT:」のテキストを表示
    screen.blit(img, (screen.get_width() - img_rect.width - 20, y_pos + 30))  # 画面右端に収まるように位置を調整

def draw_score(screen):
    score_text = font.render(f"Score: {score}", True, (0, 0, 0))
    screen.blit(score_text, (20, 20))  # スコアを画面左上に表示

def check_game_over(balls):
    for ball in balls:
        if ball.body.position.y >= screen.get_height() - ball_sizes[ball.size_index]:
            return True
    return False

def draw_game_over(screen):
    screen.fill((0, 0, 0))  # 画面を真っ黒にする
    game_over_text = game_over_font.render("GAMEOVER", True, (255, 255, 255))
    score_text = game_over_font.render(f"Score: {score}", True, (255, 255, 255))
    retry_text = game_over_font.render("RETRY", True, (255, 255, 255))
    retry_rect = retry_text.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2 + 100))

    screen.blit(game_over_text, (screen.get_width() // 2 - game_over_text.get_width() // 2, screen.get_height() // 2 - game_over_text.get_height()))
    screen.blit(score_text, (screen.get_width() // 2 - score_text.get_width() // 2, screen.get_height() // 2))
    screen.blit(retry_text, retry_rect.topleft)
    pygame.draw.rect(screen, (255, 255, 255), retry_rect.inflate(20, 10), 2)  # RETRYボタンを枠線で囲む

    return retry_rect

# ゲームをリスタートする関数
def restart_game():
    global score, balls, game_over, next_ball_index
    score = 0
    balls = []
    space.remove(*space.bodies)
    create_walls(space)
    next_ball_index = random.randint(0, 4)  # 0〜4の範囲でランダムに選択
    game_over = False

# ゲームループ
running = True
balls = []
remove_balls = []  # 削除対象のボールリストを初期化
next_ball_index = random.randint(0, 4)  # 初期の次に落ちてくるボールの種類をランダムに選ぶ（0〜4の範囲）
game_over = False

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if game_over:
                retry_rect = draw_game_over(screen)  # ゲームオーバー画面を描画し、RETRYボタンの位置を取得
                if retry_rect.collidepoint(pos):
                    restart_game()
            else:
                if pos[1] <= 100 and is_position_free(pos, balls):  # クリック位置が上から100ピクセル以内でかつボールがない場合のみボールを生成
                    ball = create_ball(space, next_ball_index, pos)
                    balls.append(ball)
                    next_ball_index = random.randint(0, 4)  # 次に落ちてくるボールの種類を更新（0〜4の範囲）

    if not game_over:
        # 更新
        space.step(1/50.0)
        game_over = check_game_over(balls)  # ゲームオーバーの確認

        # 削除対象のボールをまとめて削除
        for ball in remove_balls:
            if ball in balls:
                space.remove(ball.body, ball.shape)
                balls.remove(ball)
        remove_balls = []  # 削除リストをクリア

    # 描画
    if game_over:
        retry_rect = draw_game_over(screen)  # ゲームオーバーのテキストとRETRYボタンを表示
    else:
        screen.blit(background_image, (0, 0))  # 背景画像を描画
        draw_walls(screen)  # 壁を描画
        draw_next_ball(screen, next_ball_index)  # 次に落ちてくるボールの画像を表示
        draw_score(screen)  # スコアを表示
        for ball in balls:
            draw_ball(screen, ball)
    pygame.display.flip()
    clock.tick(50)

pygame.quit()
